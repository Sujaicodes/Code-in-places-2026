from graphics import Canvas
import random
import time

# --- Configuration Constants ---
CANVAS_WIDTH = 800
CANVAS_HEIGHT = 500
NUM_FISH = 12
NUM_BUBBLES = 30
DELAY = 0.02 

def main():
    # 1. Setup the environment
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    draw_background(canvas)
    
    print("Welcome to the Grand Digital Aquarium!")
    print("Click anywhere in the water to drop a burger for the fish!")
    
    # 2. Populate the ecosystem 
    school_of_fish = create_fish(canvas, NUM_FISH)
    bubbles = create_bubbles(canvas, NUM_BUBBLES)
    food_list = [] 
    
    # 3. The Main Animation Loop
    while True:
        # A. Listen for user clicks to drop food (with safety checks!)
        clicks = canvas.get_new_mouse_clicks()
        if clicks is not None:
            for click in clicks:
                if click is not None:
                    # click[0] is x, click[1] is y
                    drop_food(canvas, food_list, click[0], click[1])

        # B. Move bubbles normally
        for bubble in bubbles:
            move_bubble(canvas, bubble)

        # C. Move food downwards (sinking)
        for food in food_list:
            move_food(canvas, food)
            
        # D. Update fish behavior based on whether food exists
        for fish in school_of_fish:
            if len(food_list) > 0:
                # If there is food, chase the oldest piece of food in the tank!
                chase_food(canvas, fish, food_list[0])
                check_eat_food(canvas, fish, food_list)
            else:
                # Normal wandering behavior if no food
                move_fish(canvas, fish)
                
        # Pause briefly to create smooth animation
        time.sleep(DELAY)

# --- Interactivity & Food Functions ---

def drop_food(canvas, food_list, click_x, click_y):
    """Draws a multi-layered burger and adds it to the list."""
    width = 30
    
    # Draw the burger layers
    top_bun = canvas.create_oval(click_x, click_y, click_x + width, click_y + 15, color="orange")
    lettuce = canvas.create_rectangle(click_x - 2, click_y + 12, click_x + width + 2, click_y + 16, color="green")
    meat = canvas.create_rectangle(click_x + 2, click_y + 15, click_x + width - 2, click_y + 22, color="saddleBrown")
    bottom_bun = canvas.create_oval(click_x + 2, click_y + 20, click_x + width - 2, click_y + 28, color="orange")
    
    # Store all parts together
    food_data = {
        "shapes": [top_bun, lettuce, meat, bottom_bun], 
        "x": click_x,
        "y": click_y,
        "dy": 2  # Sinking speed
    }
    food_list.append(food_data)

def move_food(canvas, food):
    """Makes all parts of the burger sink slowly."""
    for part in food["shapes"]:
        canvas.move(part, 0, food["dy"])
    # Update the mathematical y-coordinate so the fish know it is sinking
    food["y"] += food["dy"]

def chase_food(canvas, fish, target_food):
    """Calculates the direction to the food and moves all fish parts toward it."""
    fish_x = canvas.get_left_x(fish["main_body"])
    fish_y = canvas.get_top_y(fish["main_body"])
    
    food_x = target_food["x"]
    food_y = target_food["y"]
    
    speed = 4 # Fish swim a little faster when they smell a burger!
    dx = 0
    dy = 0
    
    if fish_x < food_x: dx = speed
    elif fish_x > food_x: dx = -speed
    
    if fish_y < food_y: dy = speed
    elif fish_y > food_y: dy = -speed
    
    # Move the body, eye, and pupil together
    for part in fish["shapes"]:
        canvas.move(part, dx, dy)

def check_eat_food(canvas, fish, food_list):
    """Checks if the fish overlaps with the food. If so, delete the burger."""
    fish_left = canvas.get_left_x(fish["main_body"])
    fish_top = canvas.get_top_y(fish["main_body"])
    fish_right = fish_left + fish["width"]
    fish_bottom = fish_top + fish["height"]
    
    # Loop backwards through the food list safely when deleting
    for i in range(len(food_list) - 1, -1, -1):
        food = food_list[i]
        food_x = food["x"]
        food_y = food["y"]
        
        # Collision logic: Is the burger's coordinate inside the fish's body?
        if fish_left <= food_x <= fish_right and fish_top <= food_y <= fish_bottom:
            # 1. Delete every part of the burger from the canvas
            for part in food["shapes"]:
                canvas.delete(part) 
            # 2. Remove the eaten burger from the active list
            food_list.pop(i)             

# --- Environment & Fish Functions ---

def draw_background(canvas):
    """Draws the water and some static seaweed."""
    canvas.create_rectangle(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT, color="dodgerBlue")
    for i in range(12):
        x = random.randint(0, CANVAS_WIDTH)
        height = random.randint(50, 200)
        canvas.create_rectangle(x, CANVAS_HEIGHT - height, x + 15, CANVAS_HEIGHT, color="forestGreen")

def create_fish(canvas, count):
    """Generates a list of dictionaries, each holding a multi-shape fish."""
    fish_list = []
    colors = ["orange", "gold", "tomato", "hotPink", "mediumPurple"]
    
    for _ in range(count):
        size = random.randint(20, 50)
        width = size * 1.5
        height = size
        x = random.randint(50, CANVAS_WIDTH - 50)
        y = random.randint(50, CANVAS_HEIGHT - 50)
        
        dx = random.choice([-4, -3, 3, 4]) 
        dy = random.choice([-2, -1, 1, 2])
        is_facing_right = dx > 0
        
        # 1. Draw Body
        body = canvas.create_oval(x, y, x + width, y + height, color=random.choice(colors))
        
        # 2. Draw Eye
        eye_size = size * 0.25
        if is_facing_right:
            eye_x = x + width - (eye_size * 2)
        else:
            eye_x = x + eye_size
        eye_y = y + (height * 0.25)
        eye_white = canvas.create_oval(eye_x, eye_y, eye_x + eye_size, eye_y + eye_size, color="white")
        
        # 3. Draw Pupil
        pupil_size = eye_size * 0.5
        pup_x = eye_x + (pupil_size / 2)
        pup_y = eye_y + (pupil_size / 2)
        pupil = canvas.create_oval(pup_x, pup_y, pup_x + pupil_size, pup_y + pupil_size, color="black")
        
        fish_list.append({
            "shapes": [body, eye_white, pupil], 
            "main_body": body,                  
            "dx": dx, 
            "dy": dy,
            "width": width,
            "height": height
        })
        
    return fish_list

def move_fish(canvas, fish):
    """Handles normal wandering movement and wall-bouncing logic."""
    for part in fish["shapes"]:
        canvas.move(part, fish["dx"], fish["dy"])
    
    # Check boundaries using ONLY the main body
    x = canvas.get_left_x(fish["main_body"])
    y = canvas.get_top_y(fish["main_body"])
    
    if x <= 0 or (x + fish["width"]) >= CANVAS_WIDTH:
        fish["dx"] *= -1  
    if y <= 0 or (y + fish["height"]) >= CANVAS_HEIGHT:
        fish["dy"] *= -1  

def create_bubbles(canvas, count):
    """Generates ambient floating bubbles."""
    bubbles = []
    for _ in range(count):
        size = random.randint(5, 12)
        x = random.randint(0, CANVAS_WIDTH)
        y = random.randint(0, CANVAS_HEIGHT)
        shape = canvas.create_oval(x, y, x + size, y + size, color="lightCyan")
        bubbles.append({"shape": shape, "dy": random.uniform(-3, -1)})
    return bubbles

def move_bubble(canvas, bubble):
    """Moves bubbles up. If they hit the top, respawn them at the bottom."""
    canvas.move(bubble["shape"], 0, bubble["dy"])
    if canvas.get_top_y(bubble["shape"]) <= -15:
        canvas.move(bubble["shape"], 0, CANVAS_HEIGHT + 20)

if __name__ == '__main__':
    main()